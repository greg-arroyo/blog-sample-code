﻿
namespace TxtBasedBlog.Sample.Models
{
	public class BlogPost : BlogListing
	{
		public string Body { get; set; }
	}
}