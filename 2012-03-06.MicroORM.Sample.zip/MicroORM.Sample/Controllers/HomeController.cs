﻿using System.Web.Mvc;
using MicroORM.Sample.Models;

namespace MicroORM.Sample.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			ViewBag.Message = "A tiny, fast, single file micro-ORM for your .NET POCOs.";

			var viewModel = new DisplayViewModel();
			var manager = new SqlDataManager();

			viewModel.FeaturedProduct = manager.GetProductById(745); //a randomly selected ProductID from DB
			viewModel.ProductList = manager.GetProducts();

			return View(viewModel);
		}
	}
}
