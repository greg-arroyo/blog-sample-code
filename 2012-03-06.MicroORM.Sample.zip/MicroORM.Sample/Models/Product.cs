﻿using System;

namespace MicroORM.Sample.Models
{
	[PetaPoco.TableName("SalesLT.Product")]
	[PetaPoco.PrimaryKey("ProductID")]
	public class Product
	{
		// Matching AdventureWorksLT.SalesLT.Product table schema
		public int ProductID { get; set; }
		public string Name { get; set; }
		public string ProductNumber { get; set; }
		public string Color { get; set; }
		public Double StandardCost { get; set; }
		public Double ListPrice { get; set; }
		public string Size { get; set; }
		public Double Weight { get; set; }
		public string Description { get; set; }
		public string ThumbnailPhotoFileName { get; set; }
	}
}