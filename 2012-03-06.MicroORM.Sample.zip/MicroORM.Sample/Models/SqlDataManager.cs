﻿using System.Collections.Generic;

namespace MicroORM.Sample.Models
{
	public class SqlDataManager
	{
		private PetaPoco.Database db = new PetaPoco.Database("DbConnection");

		public List<Product> GetProducts()
		{
			var products = db.Fetch<Product>("SELECT TOP 10* FROM SalesLT.Product");
			return products;
		}

		public List<Product> GetProductById(int id)
		{
			// standard T-SQL syntax against context; join needed for Featured Product Description field
			// let's use PetaPoco's Sql.Bulder to do it!
			var sql = PetaPoco.Sql.Builder
				.Append("SELECT a.ProductID, a.Name, a.ProductNumber, a.Color, a.StandardCost, a.ListPrice, a.Size, a.Weight, b.Description, a.ThumbnailPhotoFileName")
				.Append("FROM SalesLT.Product a")
				.Append("LEFT OUTER JOIN SalesLT.vProductAndDescription b ON a.ProductID = b.ProductID")
				.Append("WHERE a.ProductID=@productId AND b.Culture = @culture",
					new
						{
							productId = id,
							culture = "en"
						});
			var product = db.Fetch<Product>(sql);
			return product;
		}
	}
}