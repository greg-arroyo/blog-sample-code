﻿using System.Collections.Generic;

namespace MicroORM.Sample.Models
{
	public class DisplayViewModel
	{
		public List<Product> FeaturedProduct { get; set; }
		public List<Product> ProductList { get; set; }

		public DisplayViewModel()
		{
			FeaturedProduct = new List<Product>();
			ProductList = new List<Product>();
		}
	}
}